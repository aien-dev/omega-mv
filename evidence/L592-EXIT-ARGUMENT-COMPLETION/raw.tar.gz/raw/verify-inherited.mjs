import fs from 'node:fs';import{spawnSync}from'node:child_process';import{createHash}from'node:crypto';
const sha=b=>createHash('sha256').update(b).digest('hex');const c=JSON.parse(fs.readFileSync('evidence/L562-PUBLICATION-CLOSURE/git-closure.json'));
for(const r of c.corrected_staged_git_manifest){const x=spawnSync('git',['show','HEAD:'+r.path]);if(x.status!==0||sha(x.stdout)!==r.expected_sha256)throw Error(r.path);}
const d=spawnSync('git',['diff','5583bea0','ac6fe2c7','--','src/osh', 'src/compiler', 'src/runtime', 'src/sha256.c', 'src/sha256.h', ':(exclude)**/.crumb']);if(d.status!==0||d.stdout.length)throw Error('baseline source differs');
const pins=JSON.parse(fs.readFileSync('evidence/L577-EXIT-NUMERIC-PRIORITY/binary-pins.json'));
for(const p of ['/home/drakestapleton/workspace/targets/L577/green/osh/osh','/home/drakestapleton/workspace/targets/L577/green/osh/osh_numeric_priority_asan']){if(sha(fs.readFileSync(p))!==pins[p].sha256)throw Error('baseline ELF pin mismatch');}
console.log('INHERITED_PASS: F1 original manifest 18 payloads intact in Git; baseline executable-source delta0 (crumb metadata excluded); both qualified baseline ELF hashes match L577');
