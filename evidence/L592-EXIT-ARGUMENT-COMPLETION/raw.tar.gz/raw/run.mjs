import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
const [name,cmd,...args]=process.argv.slice(2), log='targets/L592/raw/'+name;
const r=spawnSync(cmd,args,{encoding:'utf8',maxBuffer:32<<20});
fs.writeFileSync(log+'.log',(r.stdout??'')+(r.stderr??''));
fs.writeFileSync(log+'.command.json',JSON.stringify({cwd:process.cwd(),command:[cmd,...args],status:r.status,signal:r.signal,error:r.error?.message??null},null,2)+'\n');
console.log(name,'exit',r.status);console.log((r.stdout??'').trim().split('\n').slice(-4).join('\n'));process.exitCode=r.status??1;
