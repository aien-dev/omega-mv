exit '78'; printf "same-list\n"
printf "tail\n"
