exit '010'; printf "same-list\n"
printf "tail\n"
