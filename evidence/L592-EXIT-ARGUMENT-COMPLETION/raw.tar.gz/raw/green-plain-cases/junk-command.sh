exit '7x'; printf "same-list\n"
printf "tail\n"
