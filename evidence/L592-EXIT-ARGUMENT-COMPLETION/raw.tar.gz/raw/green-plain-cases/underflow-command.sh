exit '-9223372036854775809'; printf "same-list\n"
printf "tail\n"
