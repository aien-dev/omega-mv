printf "%s" "" | exit '7 '; printf "status:%s\n" "$?"
printf "tail\n"
