exit '0x10' '9'; printf "same-list\n"
printf "tail\n"
