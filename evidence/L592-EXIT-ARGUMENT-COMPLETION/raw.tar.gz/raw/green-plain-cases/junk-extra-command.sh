exit '7x' '9'; printf "same-list\n"
printf "tail\n"
