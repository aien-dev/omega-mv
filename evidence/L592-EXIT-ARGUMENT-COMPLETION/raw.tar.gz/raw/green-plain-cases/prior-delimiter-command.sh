printf "%s" "" | exit 13
exit '--'; printf "same-list\n"
printf "tail\n"
