exit '0x10'; printf "same-list\n"
printf "tail\n"
