exit '--' 'bad' '9' | printf "pipe\n"; printf "status:%s\n" "$?"
printf "tail\n"
