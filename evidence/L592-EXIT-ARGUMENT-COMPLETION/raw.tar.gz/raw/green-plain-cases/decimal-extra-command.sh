exit '7.0' '9'; printf "same-list\n"
printf "tail\n"
