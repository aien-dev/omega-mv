exit '010' '9'; printf "same-list\n"
printf "tail\n"
