exit '--' '7' | printf "pipe\n"; printf "status:%s\n" "$?"
printf "tail\n"
