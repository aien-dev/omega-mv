exit '+ 7'; printf "same-list\n"
printf "tail\n"
