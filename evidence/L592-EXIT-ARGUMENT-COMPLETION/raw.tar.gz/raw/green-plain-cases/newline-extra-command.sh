exit '7
' '9'; printf "same-list\n"
printf "tail\n"
