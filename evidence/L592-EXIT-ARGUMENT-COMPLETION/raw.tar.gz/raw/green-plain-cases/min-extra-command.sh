exit '-9223372036854775808' '9'; printf "same-list\n"
printf "tail\n"
