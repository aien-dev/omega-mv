cd /L592-missing-directory
exit '--'; printf "same-list\n"
printf "tail\n"
