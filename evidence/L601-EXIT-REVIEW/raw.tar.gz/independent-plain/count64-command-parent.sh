printf "" | exit 37
exit '--' '	-513 	' 'junk' '4'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
