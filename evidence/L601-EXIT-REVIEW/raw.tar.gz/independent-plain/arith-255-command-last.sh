printf "" | exit 37
printf "" | exit '-255'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
