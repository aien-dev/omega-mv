printf "" | exit 37
printf "" | exit '-1'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
