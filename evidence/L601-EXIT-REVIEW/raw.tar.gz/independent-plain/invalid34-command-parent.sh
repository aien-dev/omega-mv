printf "" | exit 37
exit '-18446744073709551616'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
