printf "" | exit 37
exit '1' | printf "pipe\n"; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
