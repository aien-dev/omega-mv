printf "" | exit 37
printf "" | exit '0'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
