printf "" | exit 37
printf "" | exit '+' '2' '3'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
