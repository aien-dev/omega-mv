printf "" | exit 37
exit '-257' | printf "pipe\n"; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
