printf "" | exit 37
exit ' 	 ' '2' '3' | printf "pipe\n"; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
