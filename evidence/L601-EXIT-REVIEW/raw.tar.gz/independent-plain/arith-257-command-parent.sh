printf "" | exit 37
exit '-257'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
