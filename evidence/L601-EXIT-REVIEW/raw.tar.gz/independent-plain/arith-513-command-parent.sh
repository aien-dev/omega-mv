printf "" | exit 37
exit '-513'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
