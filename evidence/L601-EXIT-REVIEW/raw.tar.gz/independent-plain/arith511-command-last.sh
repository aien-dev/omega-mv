printf "" | exit 37
printf "" | exit '511'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
