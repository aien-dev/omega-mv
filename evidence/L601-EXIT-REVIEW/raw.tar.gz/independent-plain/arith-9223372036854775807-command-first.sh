printf "" | exit 37
exit '-9223372036854775807' | printf "pipe\n"; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
