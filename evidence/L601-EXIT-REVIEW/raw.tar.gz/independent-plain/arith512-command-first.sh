printf "" | exit 37
exit '512' | printf "pipe\n"; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
