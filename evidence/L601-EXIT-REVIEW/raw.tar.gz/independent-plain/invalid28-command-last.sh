printf "" | exit 37
printf "" | exit '92233720368547758080'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
