printf "" | exit 37
printf "" | exit '-65537'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
