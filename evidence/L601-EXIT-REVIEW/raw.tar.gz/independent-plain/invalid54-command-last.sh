printf "" | exit 37
printf "" | exit '7 '; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
