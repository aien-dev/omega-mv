printf "" | exit 37
exit '-'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
