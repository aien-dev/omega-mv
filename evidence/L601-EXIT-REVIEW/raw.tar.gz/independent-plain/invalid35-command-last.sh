printf "" | exit 37
printf "" | exit '-18446744073709551616' '2' '3'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
