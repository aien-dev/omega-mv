printf "" | exit 37
exit '-1'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
