printf "" | exit 37
printf "" | exit '256'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
