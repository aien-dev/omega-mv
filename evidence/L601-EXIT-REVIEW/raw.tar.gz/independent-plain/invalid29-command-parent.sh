printf "" | exit 37
exit '92233720368547758080' '2' '3'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
