printf "" | exit 37
exit '+' | printf "pipe\n"; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
