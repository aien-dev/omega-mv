printf "" | exit 37
exit '18446744073709551615' | printf "pipe\n"; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
