printf "" | exit 37
printf "" | exit '-129'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
