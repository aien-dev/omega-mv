printf "" | exit 37
printf "" | exit '-9223372036854775807'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
