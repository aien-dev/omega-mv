printf "" | exit 37
exit '--' '-000257' 'junk' '4' | printf "pipe\n"; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
