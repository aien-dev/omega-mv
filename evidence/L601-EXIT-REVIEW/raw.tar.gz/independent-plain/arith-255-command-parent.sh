printf "" | exit 37
exit '-255'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
