printf "" | exit 37
exit '128' | printf "pipe\n"; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
