printf "" | exit 37
exit '18446744073709551615' '2' '3'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
