printf "" | exit 37
exit '7 '; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
