printf "" | exit 37
exit '256' | printf "pipe\n"; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
