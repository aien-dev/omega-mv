printf "" | exit 37
exit '-511'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
