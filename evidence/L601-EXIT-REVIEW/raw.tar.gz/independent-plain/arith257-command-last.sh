printf "" | exit 37
printf "" | exit '257'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
