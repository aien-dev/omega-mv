printf "" | exit 37
exit '127'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
