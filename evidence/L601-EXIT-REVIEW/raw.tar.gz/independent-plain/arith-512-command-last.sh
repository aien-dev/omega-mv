printf "" | exit 37
printf "" | exit '-512'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
