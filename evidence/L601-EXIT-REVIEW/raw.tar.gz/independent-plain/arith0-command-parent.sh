printf "" | exit 37
exit '0'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
