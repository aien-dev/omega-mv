printf "" | exit 37
printf "" | exit '127'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
