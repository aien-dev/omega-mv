printf "" | exit 37
printf "" | exit '-513'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
