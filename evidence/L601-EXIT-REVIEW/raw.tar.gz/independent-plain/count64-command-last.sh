printf "" | exit 37
printf "" | exit '--' '	-513 	' 'junk' '4'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
