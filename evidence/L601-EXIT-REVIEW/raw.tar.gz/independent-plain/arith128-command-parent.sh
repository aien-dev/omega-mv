printf "" | exit 37
exit '128'; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
