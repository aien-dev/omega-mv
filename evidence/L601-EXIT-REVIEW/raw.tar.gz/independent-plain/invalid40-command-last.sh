printf "" | exit 37
printf "" | exit ''; printf "same:%s\n" "$?"
printf "next:%s\n" "$?"
