exit bad 9 10; printf "same-list\n"
printf "tail\n"
