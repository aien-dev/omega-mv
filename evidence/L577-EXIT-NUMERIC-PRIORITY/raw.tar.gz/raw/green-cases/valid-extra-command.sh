exit 1 2; printf "same-list\n"
printf "tail\n"
