printf "%s" ""
exit; printf "same-list\n"
printf "tail\n"
