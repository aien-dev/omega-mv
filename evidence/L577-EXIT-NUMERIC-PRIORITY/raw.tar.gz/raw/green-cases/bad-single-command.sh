exit bad; printf "same-list\n"
printf "tail\n"
