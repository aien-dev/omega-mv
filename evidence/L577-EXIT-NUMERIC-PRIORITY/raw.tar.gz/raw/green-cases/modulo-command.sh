exit 256; printf "same-list\n"
printf "tail\n"
