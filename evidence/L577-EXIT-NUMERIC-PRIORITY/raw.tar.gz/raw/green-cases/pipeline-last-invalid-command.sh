printf "%s" "" | exit bad 9; printf "status:%s\n" "$?"
printf "tail\n"
