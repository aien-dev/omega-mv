printf "%s" "" | exit 7 9; printf "status:%s\n" "$?"
printf "tail\n"
