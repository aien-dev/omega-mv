exit 9223372036854775807 9; printf "same-list\n"
printf "tail\n"
