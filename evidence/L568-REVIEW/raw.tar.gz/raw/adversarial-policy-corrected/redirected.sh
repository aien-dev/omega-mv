exit 4 5 >&1
printf "%s\n" "$?"