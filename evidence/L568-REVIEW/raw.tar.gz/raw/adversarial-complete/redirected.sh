exit 4 5 >/dev/null
printf "%s\n" "$?"