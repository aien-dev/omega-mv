exit bad 9
printf "tail\n"