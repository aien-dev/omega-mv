false || exit 3 4
printf "%s\n" "$?"