exit 257
printf "tail\n"