exit -1 9
printf "%s\n" "$?"
printf "tail\n"