# Omega Bridge design

## User goal
A standalone repo that enables Omega to attach to existing languages and tools, convert efficiently, replace invisible internals, and leave familiar interfaces intact. Adoption should demand as little change as possible. Target broad language reach, not a false claim that arbitrary languages already translate perfectly.

## Coordinator architecture decision
Use one checked Omega semantic core with target adapters, not N-by-N text replacements. Implement converter logic and emitted runtimes in Omega wherever the existing language can express them. C output provides a native interoperability route; Python source output provides a directly executable first second-language backend. Distinguish source conversion from a language binding: a binding calls qualified Omega code and does not pretend to translate arbitrary host-language programs. Add other languages via a documented adapter/capability contract. New language inputs require their own checked frontends.

## Required semantics
Fixed widths, explicit conversions, bounded arrays with carried lengths, preserved operation order and alias rules, exact observable stdout/exit/trap/refusal behavior within the declared subset. Unsupported dynamic/reflection/concurrency/foreign-runtime semantics must refuse explicitly, with a clear diagnostic. Generated C must avoid undefined behavior; Python must reproduce fixed-width behavior rather than silently use unbounded arithmetic. GCC and Python are target tools/oracles, not dependencies of Omega's seed birth.

## Acceptance
First deliver C and Python for an explicit supported Omega subset and an honest feature matrix. Reuse L440 recovered source without editing its tree. Build converter using the qualified seed, run native Omega and emitted C/Python on the same corpus including forward/mutual calls, fib, bytecopy/echo/sort, signed and unsigned boundaries, bounds/conversion traps and malformed inputs. Add mutation controls and repeatability. Prove a real C caller and a Python caller can invoke a converted Omega function; document copy/ownership/ABI costs. No GPU, driver, live motor or systemwide replacements.

## Adoption and efficiency
CLI first, noninteractive reproducible build, examples a stranger can run without GPU. Defaults inspect or build an isolated candidate, never overwrite another application. Include dry-run, explicit opt-in, rollback path, and compatibility checks before replacing an implementation. Measure conversion time and end-to-end runtime/call overhead against the same workload and record all results, including regressions. Massive speedups are a goal, not a claim. Preserve correctness before any default replacement.

## Scope boundaries
Do not install Jarvis, switch drivers, change 18091, alter other worktrees, or claim arbitrary Python-to-Omega/C-to-Omega conversion. A universal framework is extensible; each actual language support needs its own executable gates. Preserve original AGPL licence and record recovered-source provenance. Audit before any public flip.

## Implemented architecture and study reconciliation (L483)

The recovered lexer, name lookup and two-pass signature scan remain in src/toc.om. The pinned Omega-written seed is the whole-unit semantic checker, invoked by tools/bridge on an immutable source snapshot. The target compiler constructs bounded typed expression nodes (literal/local/operator/cast/get/len/call/I/O) and uses dedicated C and Python writers. C sequences operands before runtime helper calls. Python emits calls to the same semantic operations. This is source generation from parsed nodes, not textual substitution. Shell handles files and processes; Python test code only runs oracles, callers and measurements.

Relied-on decisions from PROGRAM 16-24: length-carrying arrays (16), shape and view/edit checks (17), alias refusals (18), defined arithmetic and trap behavior (19), explicit widths/conversions (20), whole-unit checking (21), fixed grammar (22), checked bounds (23), fixed source allocations (24). Native bounds proofs and checker2 receipts are not imported as claims. The bridge retains runtime checks. Python's interpreter allocation is disclosed separately from the source language's allocation rules.

The study/languages reference is pinned to b7859ab081f098f68536759c96bb086b1c1621ea. Its decisions 26-45 were proposals, not an acceptance record. This implementation applies the C ABI route (26), refusal of unsupported features (32), compatibility through translation rather than syntax supersetting (40), no unchecked source escape (41), zero-based arrays (43), and written signatures plus inference (44). Checks have no disabling switch (30). Library wrappers return errors as values (29). The bootstrap uses an exact source dependency (36). Recorded timings address 38 without a speed claim.

The broader COMPATIBILITY C0-C8 design remains a roadmap. This bridge's experimental all-u64 scalar ABI, target C/Python runtimes and conservative resource limits do not complete its stable typed ABI, dependency-free ELF, per-caller workspace, DLPack, threading or outward-call gates (26, 31, 35, 37, 45). Version coexistence (27), GPU tiles (34), generics (39) and wider packaging (36) are not implemented here. Null source references (28) remain absent, and foreign null buffers are rejected. Visible control/allocation (42) is retained at the Omega source level; Python runtime allocation is not hidden from the capability document. Ahead-of-time output (33) is implemented without claiming a signed checker2 receipt.

The bootstrap study distinguishes a fixpoint from DDC. tools/bootstrap.sh reconstructs seed0, hex1, asm2, om4 and omc from pinned source, verifies nonempty AArch64 ELF at every execution step, and compares three omc stages. This is a reproducibility/fixpoint gate. Both parent routes descend from related seed code, so this is not independent DDC. GCC and Python execute target results only. The bridge itself is built in Omega by that seed; converting its own source through the narrower bridge is not claimed.

Local gates: tests/differential.py (execution parity and known-answer checks), tests/refusals.py (frontend and capability refusals), tests/attachments.py (actual host callers), tests/controls.py (damaged outputs detected), tests/robustness.py (all byte-prefix truncations and capacity inputs). Evidence records actual results and hashes. Resource limits and ABI obligations live in CAPABILITIES.md and ABI.md and bound every correctness claim.
